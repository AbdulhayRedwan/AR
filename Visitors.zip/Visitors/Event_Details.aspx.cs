﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Visitors_Event_Details : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["App_conniction"].ConnectionString);

            if (!IsPostBack)
            {
                FillData();

            }
        }
        catch (Exception ex)
        {
            Response.Redirect("Default.aspx");
        }

    }
     
    private void FillData()
    {
        
        string x = Request.QueryString["tag"].ToString(); 
        Events_Search(int.Parse(x), 0, 0, "", "", "", "",0);  
    
    }


    private DataTable Events_Search(int _Id, int _Event_Manager_Id, int _Tourist_Place_Id, string _Name, string _Description, string _Date_Times, string _Conditions, int _Tickit_Price)
    {
        cmd = new SqlCommand();
        SqlDataAdapter da = default(SqlDataAdapter);
        dt = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Events_Search";
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = _Id;
            cmd.Parameters.Add("@Event_Manager_Id", SqlDbType.Int).Value = _Event_Manager_Id;
            cmd.Parameters.Add("@Tourist_Place_Id", SqlDbType.Int).Value = _Tourist_Place_Id;
            cmd.Parameters.Add("@Tickit_Price", SqlDbType.Int).Value = _Tickit_Price; 
            cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = _Name;
            cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = _Description; 
            cmd.Parameters.Add("@Conditions", SqlDbType.NVarChar).Value = _Conditions;
            cmd.Parameters.Add("@Date_Times", SqlDbType.NVarChar).Value = _Date_Times;

             
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                 
        //EV.[Id],0
        //EV.[Event_Manager_Id],1
        //EV.[Tourist_Place_Id],2
        //EV.[Tickit_Price],3
        //EV.[Name],4

        //EV.[Description],5
        //EV.[Img1],6
        //EV.[Conditions],7
        //EV.[Date_Times],8
        //TP.City_Id,9
        //TP.Tourism_Type_Id,10
        //TP.Name as 'Place_Name',11
        //CC.Name as 'City_Name',12
        //TT.Name as 'Tourism_Type_Name',13
                 
                lbl_Id.Text = dt.Rows[0][0].ToString();

                lbl_tickets.Text = dt.Rows[0][3].ToString();
                lbl_Name.Text = dt.Rows[0][4].ToString();
                lbl_Name1.Text = dt.Rows[0][4].ToString();

                lbl_Description.Text = dt.Rows[0][5].ToString();
                string ImageUrl = "../Admin/" + dt.Rows[0][6].ToString();
                Image1.ImageUrl = "../Admin/" + dt.Rows[0][6].ToString();
                x1.Attributes.Add("style", "background-image:url(" + ImageUrl + ")");

                lbl_Conditions.Text = dt.Rows[0][7].ToString();
                lbl_DateTime.Text = dt.Rows[0][8].ToString();
                 lbl_Tourism_Type_Name.Text = dt.Rows[0][13].ToString();

                //lbl_City_Name.Text = dt.Rows[0][14].ToString();
              

            }
         

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
        return dt;
    }




 
}
