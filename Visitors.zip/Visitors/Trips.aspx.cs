﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Visitors_Trips : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["App_conniction"].ConnectionString);

            if (!IsPostBack)
            {
                Tourit_Places_Search(0, 0, 0, "", "", "", "", "", "", "");


            }

        }
        catch (Exception ex)
        {
            Response.Redirect("Default.aspx");
        }
        //Repeater1
    }

    private DataTable Tourit_Places_Search(int _Id, int _City_Id, int _Tourism_Type_Id, string _Name, string _Opining_Hours, string _Description, string _Conditions, string _Location, string _Visitor_Counts, string _Tickits_Prices)
    {
        cmd = new SqlCommand();
        SqlDataAdapter da = default(SqlDataAdapter);
        dt = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Tourit_Places_Search";
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = _Id;
            cmd.Parameters.Add("@City_Id", SqlDbType.Int).Value = _City_Id;
            cmd.Parameters.Add("@Tourism_Type_Id", SqlDbType.Int).Value = _Tourism_Type_Id;

            cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = _Name;
            cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = _Description;
            cmd.Parameters.Add("@Location", SqlDbType.NVarChar).Value = _Location;

            cmd.Parameters.Add("@Conditions", SqlDbType.NVarChar).Value = _Conditions;
            cmd.Parameters.Add("@Opining_Hours", SqlDbType.NVarChar).Value = _Opining_Hours;
            cmd.Parameters.Add("@Visitor_Counts", SqlDbType.NVarChar).Value = _Visitor_Counts;
            cmd.Parameters.Add("@Tickits_Prices", SqlDbType.NVarChar).Value = _Tickits_Prices;




            da = new SqlDataAdapter(cmd);
            da.Fill(dt);


            Repeater1.DataSource = dt;
            Repeater1.DataBind();

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
        return dt;
    }


    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "ViewDetail")
        {
            int id = int.Parse(e.CommandArgument.ToString());
            Response.Redirect("~/Visitors/Trip_Details.aspx?tag=" + id);

        }
    }
}