﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Visitors_Guide_Details : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["App_conniction"].ConnectionString);

            if (!IsPostBack)
            {
                HyperLink1.Visible = false;
                FillData();

            }
        }
        catch (Exception ex)
        {
            Response.Redirect("Default.aspx");
        }

    }

    private void FillData()
    {

        string x = Request.QueryString["tag"].ToString();
        Guider_Places_Search(int.Parse(x), 0, 0, "", "");

    }



    private DataTable Guider_Places_Search(int _Id, int _Guider_Id, int _Tourist_Place_Id, string _Details, string _Price_Hour)
    {
        cmd = new SqlCommand();
        SqlDataAdapter da = default(SqlDataAdapter);
        dt = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Guider_Places_Search";
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = _Id;
            cmd.Parameters.Add("@Guider_Id", SqlDbType.Int).Value = _Guider_Id;
            cmd.Parameters.Add("@Tourist_Place_Id", SqlDbType.Int).Value = _Tourist_Place_Id;
            cmd.Parameters.Add("@Details", SqlDbType.NVarChar).Value = _Details;
            cmd.Parameters.Add("@Price_Hour", SqlDbType.NVarChar).Value = _Price_Hour;

            da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count == 1)
            {

                lbl_Id.Text = dt.Rows[0][0].ToString();
                lbl_Tourist_Place_Id.Text = dt.Rows[0][1].ToString();
                lbl_Guider_Id.Text = dt.Rows[0][2].ToString();

                lbl_Place_Name.Text = dt.Rows[0][5].ToString();
                lbl_GuideName.Text = dt.Rows[0][9].ToString();
               
                // lbl_Guide.Text = dt.Rows[0][9].ToString();
                lbl_Details.Text = dt.Rows[0][3].ToString();
                lbl_Price_Hour.Text = dt.Rows[0][4].ToString();


                
        //GP.[Id],0
        //GP.[Tourist_Place_Id],1
        //GP.[Guider_Id],2
        //GP.[Details],3
        //GP.[Price_Hour], 4
        //TP.Name as 'Tourit_Places_Name',5
        //TP.City_Id, 6
        //C.Name as 'City_Name', 7

        //G.Full_Name +'-'+ TP.Name as 'Guider_Places',8
        //G.Full_Name as 'Guider_Name',9
		  
            }
            

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
        return dt;
    }


    protected void lbl_Booking_Click(object sender, EventArgs e)
    {
       
        try
        {
            string date = System.DateTime.Now.ToString();


            int _Guider_Places_Id = 0;
            int.TryParse(lbl_Id.Text.ToString(), out _Guider_Places_Id);



            int _Tourist_Session_Id = 0;
            int.TryParse(Session["Tourist_Session_Id"].ToString(), out _Tourist_Session_Id);

            HyperLink1.Visible = true;
            if (_Guider_Places_Id > 0)
            {


                bool x = Tourist_Guider_Booking_Save(0, _Guider_Places_Id, _Tourist_Session_Id, date, "");

                if (x == true)
                {

                    HyperLink1.NavigateUrl = "../Tourists/Tour_Services.aspx";

                    lbl_SaveSuccess.Text = " Booked successfully";

                }
                else
                {
                    lbl_SaveSuccess.Text = " Not Booked";
                }

            }

        }
        catch (Exception ex) {

            lbl_SaveSuccess.Text = " Please Try to make a login to your account .... ";
        }
    }


    private DataTable Tourist_Guider_Booking_Search(int _Id, int _Guider_Places_Id, int _Tourist_Id, string _Date_Time, string _Notes)
    {
        cmd = new SqlCommand();
        SqlDataAdapter da = default(SqlDataAdapter);
        dt = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Tourist_Guider_Booking_Search";
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = _Id;

            cmd.Parameters.Add("@Guider_Places_Id", SqlDbType.Int).Value = _Guider_Places_Id;
            cmd.Parameters.Add("@Tourist_Id", SqlDbType.Int).Value = _Tourist_Id;
            cmd.Parameters.Add("@Date_Time", SqlDbType.NVarChar).Value = _Date_Time;
            cmd.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = _Notes;


            da = new SqlDataAdapter(cmd);
            da.Fill(dt);


            if (dt.Rows.Count == 1)
            {

                lbl_Id.Text = dt.Rows[0][0].ToString();
                //Ddl_Guider_Places_Id.SelectedValue = dt.Rows[0][1].ToString();
               // ddl_Tourist_Id.SelectedValue = dt.Rows[0][2].ToString();
                //txt_Date_Time.Text = dt.Rows[0][3].ToString();
              //  txt_Notes.Text = dt.Rows[0][4].ToString();

            }
            

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
        return dt;
    }

    public bool Tourist_Guider_Booking_Save(int _id, int _Guider_Places_Id, int _Tourist_Id, string _Date_Time, string _Notes)
    {
        cmd = new SqlCommand();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Tourist_Guider_Booking_Save";
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = _id;
            cmd.Parameters.Add("@Guider_Places_Id", SqlDbType.Int).Value = _Guider_Places_Id;
            cmd.Parameters.Add("@Tourist_Id", SqlDbType.Int).Value = _Tourist_Id;
            cmd.Parameters.Add("@Date_Time", SqlDbType.NVarChar).Value = _Date_Time;
            cmd.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = _Notes;

            if (cmd.ExecuteNonQuery() > 0)
            {
                con.Close();
                return false;
            }
            else
            {
                con.Close();
                return true;

            }

        }
        catch (Exception ex)
        {
            con.Close();
            return false;

        }
    }

}
